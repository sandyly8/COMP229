import './App.css'
import Multiple from "./components/Multiple/Multiple";

const App = () => {
  return (
    <div>
      { <Multiple /> }
    </div>
  );
};

export default App
